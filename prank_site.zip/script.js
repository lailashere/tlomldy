setTimeout(() => {
  window.location.href = "message.html";
}, 5000); // بعد 5 ثواني
